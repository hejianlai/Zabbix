#!/bin/bash
source ~/.bash_profile
RESULT=/mnt/sscp/app/zabbix/scripts/result
. oraenv <<EOF
SSCPSITC
EOF
get_auto_tablespace (){
sqlplus 'C##SSCPTMON/Abcd#12345' <<EOF
alter session set container=sscpsitp;
set numformat 999999990.00
column value new_value dbblocksz noprint
select value from v\$parameter where name = 'db_block_size';

compute sum of used_mb on report
compute sum of size_mb on report
break on report

select a.tablespace_name,
       (used_space*&dbblocksz)/(1024*1024) used_mb,
       b.mb size_mb,
       (tablespace_size*&dbblocksz)/(1024*1024) max_mb,
       ((used_space*&dbblocksz)/(1024*1024)/b.mb*100) percent,
       used_percent max_percent
from dba_tablespace_usage_metrics a,
     (select tablespace_name, sum(bytes/1024/1024) mb, sum(maxbytes/1024/1024) max_mb from dba_data_files group by tablespace_name
      union all
      select tablespace_name, sum(bytes/1024/1024) mb, sum(maxbytes/1024/1024) max_mb from dba_temp_files group by tablespace_name) b
where a.tablespace_name = b.tablespace_name
union all
select f.tablespace_name, 
  (sum(f.bytes)-sum(fs.bytes))/1024/1024 used_mb , 
  sum(f.bytes)/1024/1024 size_mb, 
  sum(f.maxbytes)/1024/1024 max_mb,
  (sum(f.bytes)-sum(fs.bytes))/sum(f.bytes)*100 percent,
  (sum(f.bytes)-sum(fs.bytes))/sum(f.maxbytes)*100 max_percent
from dba_data_files f, 
     (select tablespace_name, sum(bytes) bytes from dba_free_space where tablespace_name like 'UNDO%' group by tablespace_name) fs
where fs.tablespace_name = f.tablespace_name
group by f.tablespace_name
/
exit;
EOF
}
get_auto_tablespace  >${RESULT}/auto_tablespace.txt
