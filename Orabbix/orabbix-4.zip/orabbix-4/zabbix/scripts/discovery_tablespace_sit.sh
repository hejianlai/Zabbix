#!/bin/bash
#
# zabbix discovery Oracle tablespace
table_spaces=(`cat /mnt/sscp/log/tablespace/free_tablespace.SSCPSITP.txt| sed -e "1,3d" -e "/^$/d" -e "/selected/d" | awk '{print $1}'|grep -E '^TBS'`)
length=${#table_spaces[@]}
printf "{\n"
printf '\t'"\"data\":["
for ((i=0;i<$length;i++))
do
    printf "\n\t\t{"
    printf "\"{#TABLESPACE_NAME}\":\"${table_spaces[$i]}\"}"
    if [ $i -lt $[$length-1] ];then
        printf ","
    fi
done
    printf "\n\t]\n"
printf "}\n"
