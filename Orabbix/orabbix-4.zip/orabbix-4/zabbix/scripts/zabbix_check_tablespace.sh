#!/bin/bash
#
# zabbix check oracle tablespace

CEHCK_TYPE=$1
TABLESPACE_NAME=$2

function usagepre {
    grep "\b$TABLESPACE_NAME\b" /mnt/sscp/log/tablespace/free_tablespace.SSCPSITP.txt | awk '{print $6}'
}
function available {
    grep "\b$TABLESPACE_NAME\b" /mnt/sscp/log/tablespace/free_tablespace.SSCPSITP.txt | awk '{print $4-$2 }'
}
function check {
    if grep "\b$TABLESPACE_NAME\b" /tmp/ora_autex.txt | awk '{print $2}' | uniq | grep -i "YES" &>/dev/null;then
        echo "YES"
    else
        echo "NO"
    fi
}
case $CEHCK_TYPE in
    pre)
        usagepre ;;
    free)
        available ;;
    check)
        check ;;
    *)
        echo -e "Usage: $0 [pre|free|check] [TABLESPACE_NAME]"
esac
